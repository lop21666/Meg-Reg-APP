(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-reset-password-reset-password-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/reset-password/reset-password.page.html":
    /*!*****************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/reset-password/reset-password.page.html ***!
      \*****************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesResetPasswordResetPasswordPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\" color=\"light\">Atrás\n        <ion-icon slot=\"start\" name=\"arrow-back-outline\" color=\"light\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Seguridad</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card *ngIf=\"mostrarData\" class=\"animated fadeIn fast\">\n    <ion-card-header>\n      <ion-card-title class=\"ion-text-center\">\n        Usuario y contraseña\n      </ion-card-title>\n    </ion-card-header>\n    <ion-card-content>\n  <form (ngSubmit)=\"resetPassword()\" [formGroup]=\"changeForm\">\n    <ion-list>\n      <small>Nombre de Usuario:*</small>\n      <ion-item mode=\"md\">\n        <ion-icon slot=\"start\" name=\"person\"></ion-icon>\n        <ion-input placeholder=\"User\" type=\"name\" formControlName=\"nombre\">\n        </ion-input>\n      </ion-item>\n      <div class=\"errors\" *ngIf=\"nombre.invalid && (nombre.dirty || nombre.touched)\">\n        <span *ngIf=\"nombre.errors.required\">\n          <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n        </span>\n      </div>\n      <small>Usuario:*</small>\n      <ion-item mode=\"md\">\n        <ion-icon slot=\"start\" name=\"person-circle-outline\"></ion-icon>\n        <ion-input placeholder=\"User\" type=\"name\" clearOnEdit=\"true\" clearInput formControlName=\"usuario\">\n        </ion-input>\n      </ion-item>\n      <div class=\"errors\" *ngIf=\"usuario.invalid && (usuario.dirty || usuario.touched)\">\n        <span *ngIf=\"usuario.errors.required\">\n          <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n        </span>\n      </div>\n      <small>Contraseña:*</small>\n      <ion-item mode=\"md\">\n        <ion-icon slot=\"start\" name=\"lock-open\"></ion-icon>\n        <ion-icon slot=\"end\" name=\"checkmark-circle-sharp\" *ngIf=\"password.value == confirmPassword.value && password.value != '' && (confirmPassword.dirty || confirmPassword.touched)\" class=\"valid-icon\"></ion-icon>\n        <ion-icon slot=\"end\" name=\"close-circle-sharp\" *ngIf=\"password.value != confirmPassword.value && (confirmPassword.dirty || confirmPassword.touched)\" class=\"valid-icon-X\"></ion-icon>\n        <ion-input placeholder=\"Password\" type=\"password\" clearOnEdit=\"true\" formControlName=\"password\" (ngModelChange)=\"seguridad_clave(password.value)\">\n        </ion-input>\n      </ion-item>\n      <div class=\"errors\" *ngIf=\"password.invalid && (password.dirty || password.touched)\">\n        <span *ngIf=\"password.errors.required\">\n          <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n        </span>\n      </div>\n      <small>Confirmar Contraseña:*</small>\n      <ion-item mode=\"md\">\n        <ion-icon slot=\"start\" name=\"lock-open\"></ion-icon>\n        <ion-icon slot=\"end\" name=\"checkmark-circle-sharp\" *ngIf=\"password.value == confirmPassword.value && confirmPassword.value != '' && (confirmPassword.dirty || confirmPassword.touched)\" class=\"valid-icon\"></ion-icon>\n        <ion-icon slot=\"end\" name=\"close-circle-sharp\" *ngIf=\"password.value != confirmPassword.value && (confirmPassword.dirty || confirmPassword.touched)\" class=\"valid-icon-X\"></ion-icon>\n        <ion-input placeholder=\"Password\" type=\"password\" clearOnEdit=\"true\" formControlName=\"confirmPassword\">\n        </ion-input>\n      </ion-item>\n      <div class=\"errors\" *ngIf=\"confirmPassword.invalid && (confirmPassword.dirty || confirmPassword.touched)\">\n        <span *ngIf=\"confirmPassword.errors.required\">\n          <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n        </span>\n      </div>\n    </ion-list>\n    <ion-list>\n      <ion-progress-bar class=\"progress\" [value]=\"valueBar\" [color]=\"color\"></ion-progress-bar>\n    </ion-list>\n    <ion-grid>\n      <br>\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-button expand=\"block\" class=\"button-clean\" fill=\"outline\" color=\"dark\" (click)=\"clean()\"\n            strong=\"true\">Limpiar\n            <ion-icon slot=\"start\" color=\"black\" name=\"close-circle-outline\"></ion-icon>\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-button expand=\"block\" class=\"button-save\" type=\"submit\" [disabled]=\"!changeForm.valid || password.value != confirmPassword.value\"\n            strong=\"true\">Guardar\n            <ion-icon slot=\"start\" color=\"white\" name=\"save\"></ion-icon>\n          </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </form>\n</ion-card-content>\n</ion-card>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/pages/reset-password/reset-password-routing.module.ts":
    /*!***********************************************************************!*\
      !*** ./src/app/pages/reset-password/reset-password-routing.module.ts ***!
      \***********************************************************************/

    /*! exports provided: ResetPasswordPageRoutingModule */

    /***/
    function srcAppPagesResetPasswordResetPasswordRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ResetPasswordPageRoutingModule", function () {
        return ResetPasswordPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _reset_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./reset-password.page */
      "./src/app/pages/reset-password/reset-password.page.ts");

      var routes = [{
        path: '',
        component: _reset_password_page__WEBPACK_IMPORTED_MODULE_3__["ResetPasswordPage"]
      }];

      var ResetPasswordPageRoutingModule = function ResetPasswordPageRoutingModule() {
        _classCallCheck(this, ResetPasswordPageRoutingModule);
      };

      ResetPasswordPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ResetPasswordPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/reset-password/reset-password.module.ts":
    /*!***************************************************************!*\
      !*** ./src/app/pages/reset-password/reset-password.module.ts ***!
      \***************************************************************/

    /*! exports provided: ResetPasswordPageModule */

    /***/
    function srcAppPagesResetPasswordResetPasswordModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ResetPasswordPageModule", function () {
        return ResetPasswordPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _reset_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./reset-password-routing.module */
      "./src/app/pages/reset-password/reset-password-routing.module.ts");
      /* harmony import */


      var _reset_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./reset-password.page */
      "./src/app/pages/reset-password/reset-password.page.ts");

      var ResetPasswordPageModule = function ResetPasswordPageModule() {
        _classCallCheck(this, ResetPasswordPageModule);
      };

      ResetPasswordPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _reset_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["ResetPasswordPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
        declarations: [_reset_password_page__WEBPACK_IMPORTED_MODULE_6__["ResetPasswordPage"]]
      })], ResetPasswordPageModule);
      /***/
    },

    /***/
    "./src/app/pages/reset-password/reset-password.page.scss":
    /*!***************************************************************!*\
      !*** ./src/app/pages/reset-password/reset-password.page.scss ***!
      \***************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesResetPasswordResetPasswordPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar {\n  --background: #2D383F;\n  color: white;\n}\n\nion-icon {\n  color: #508bfa;\n}\n\nion-input {\n  --color: black;\n}\n\nion-list {\n  background-color: #FFF;\n  padding-top: 7%;\n}\n\nion-item {\n  --border-color: transparent !important;\n  --background: #F7F7F6;\n  border-radius: 14px;\n  margin-bottom: 10px;\n  margin-top: 10px;\n}\n\n.button-save {\n  --background: #2D383F;\n  color: white;\n  margin-top: 10%;\n}\n\nion-content {\n  --background: #F4F3EF;\n}\n\n.container {\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n\n.button-clean {\n  --background: white;\n  margin-top: 10%;\n}\n\n.valid-icon {\n  color: #07c007;\n}\n\n.valid-icon-X {\n  color: #d80606;\n}\n\n.progress {\n  height: 17px;\n  border-radius: 14px;\n  box-shadow: inset 0 2px 9px rgba(255, 255, 255, 0.3), inset 0 -2px 6px rgba(0, 0, 0, 0.4);\n  position: relative;\n  overflow: hidden;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcmVzZXQtcGFzc3dvcmQvcmVzZXQtcGFzc3dvcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBRUE7RUFDRSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxzQkFBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLHNDQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDRSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFDSjs7QUFFQTtFQUNFLG1CQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLG1CQUFBO0VBQ0EseUZBQ0U7RUFFRixrQkFBQTtFQUNBLGdCQUFBO0FBREYiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9yZXNldC1wYXNzd29yZC9yZXNldC1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogIzJEMzgzRjtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuaW9uLWljb24ge1xyXG4gIGNvbG9yOiByZ2IoODAsIDEzOSwgMjUwKTtcclxufVxyXG5cclxuaW9uLWlucHV0IHtcclxuICAtLWNvbG9yOiBibGFjaztcclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNGRkY7XHJcbiAgcGFkZGluZy10b3A6IDclO1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjRjdGN0Y2O1xyXG4gIGJvcmRlci1yYWRpdXM6IDE0cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG4uYnV0dG9uLXNhdmV7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjMkQzODNGO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBtYXJnaW4tdG9wOiAxMCU7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50e1xyXG4gIC0tYmFja2dyb3VuZDogI0Y0RjNFRjtcclxufVxyXG5cclxuLmNvbnRhaW5lciB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uYnV0dG9uLWNsZWFue1xyXG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgbWFyZ2luLXRvcDogMTAlO1xyXG59XHJcblxyXG4udmFsaWQtaWNvbntcclxuICBjb2xvcjogcmdiKDcsIDE5MiwgNyk7XHJcbn1cclxuXHJcbi52YWxpZC1pY29uLVh7XHJcbiAgY29sb3I6IHJnYigyMTYsIDYsIDYpO1xyXG59XHJcblxyXG4ucHJvZ3Jlc3N7XHJcbiAgaGVpZ2h0OiAxN3B4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDE0cHg7XHJcbiAgYm94LXNoYWRvdzogXHJcbiAgICBpbnNldCAwIDJweCA5cHggIHJnYmEoMjU1LDI1NSwyNTUsMC4zKSxcclxuICAgIGluc2V0IDAgLTJweCA2cHggcmdiYSgwLDAsMCwwLjQpO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG59XHJcbiJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/reset-password/reset-password.page.ts":
    /*!*************************************************************!*\
      !*** ./src/app/pages/reset-password/reset-password.page.ts ***!
      \*************************************************************/

    /*! exports provided: ResetPasswordPage */

    /***/
    function srcAppPagesResetPasswordResetPasswordPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ResetPasswordPage", function () {
        return ResetPasswordPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/services/alert.service */
      "./src/app/services/alert.service.ts");
      /* harmony import */


      var src_app_services_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/services/user.service */
      "./src/app/services/user.service.ts");

      var ResetPasswordPage = /*#__PURE__*/function () {
        function ResetPasswordPage(navCtrl, userService, storage, alertService) {
          _classCallCheck(this, ResetPasswordPage);

          this.navCtrl = navCtrl;
          this.userService = userService;
          this.storage = storage;
          this.alertService = alertService;
          this.mostrarData = false;
          this.valueBar = 0;
          this.color = 'danger';
          this.changeForm = this.createFormGroup();
        }

        _createClass(ResetPasswordPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            this.getData();
          }
        }, {
          key: "createFormGroup",
          value: function createFormGroup() {
            return new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
              nombre: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]({
                value: '',
                disabled: true
              }, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
              usuario: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
              password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
              confirmPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
            });
          }
        }, {
          key: "defaultValue",
          value: function defaultValue(perfilData) {
            this.changeForm.controls.nombre.setValue(perfilData.nombre);
            this.changeForm.controls.usuario.setValue(perfilData.usu);
          }
        }, {
          key: "getData",
          value: function getData() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var datosUsuario;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.storage.get('datos');

                    case 2:
                      datosUsuario = _context.sent;

                      if (!datosUsuario) {
                        _context.next = 7;
                        break;
                      }

                      _context.next = 6;
                      return this.userService.getPassword(datosUsuario.codigo);

                    case 6:
                      _context.sent.subscribe(function (resp) {
                        _this.perfilData = resp.data;

                        _this.defaultValue(_this.perfilData);

                        _this.mostrarData = true;
                      });

                    case 7:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "back",
          value: function back() {
            this.navCtrl.back({
              animated: true
            });
          }
        }, {
          key: "clean",
          value: function clean() {
            this.changeForm.controls.usuario.setValue('');
            this.changeForm.controls.password.setValue('');
            this.changeForm.controls.confirmPassword.setValue('');
          }
        }, {
          key: "resetPassword",
          value: function resetPassword() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this2 = this;

              var datosUsuario;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.storage.get('datos');

                    case 2:
                      datosUsuario = _context2.sent;

                      if (!datosUsuario) {
                        _context2.next = 8;
                        break;
                      }

                      _context2.next = 6;
                      return this.userService.setPassword(datosUsuario.codigo, this.changeForm.value.usuario, this.changeForm.value.password);

                    case 6:
                      _context2.next = 8;
                      return _context2.sent.subscribe(function (resp) {
                        if (resp.status) {
                          _this2.alertService.presentAlert('Contraseña y usuario actualizado!');

                          _this2.mostrarData = false;

                          _this2.changeForm.reset();

                          _this2.valueBar = 0;

                          _this2.getData();
                        } else {
                          _this2.alertService.presentAlert('Ha ocurrido un error, intenta más tarde');
                        }
                      });

                    case 8:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "seguridad_clave",
          value: function seguridad_clave(clave) {
            var seguridad = 0;

            if (clave.length !== 0) {
              if (this.tiene_numeros(clave) && this.tiene_letras(clave)) {
                seguridad += 30;
              }

              if (this.tiene_minusculas(clave) && this.tiene_mayusculas(clave)) {
                seguridad += 30;
              }

              if (clave.length >= 4 && clave.length <= 5) {
                seguridad += 10;
              } else {
                if (clave.length >= 6 && clave.length <= 8) {
                  seguridad += 30;
                } else {
                  if (clave.length > 8) {
                    seguridad += 40;
                  }
                }
              }
            }

            seguridad *= 0.01;

            if (0.35 >= seguridad) {
              this.color = 'danger';
            } else if (seguridad >= 0.36 && 0.80 >= seguridad) {
              this.color = 'warning';
            } else {
              this.color = 'success';
            }

            this.valueBar = seguridad;
          }
        }, {
          key: "tiene_numeros",
          value: function tiene_numeros(texto) {
            var numeros = '0123456789';
            var i;

            for (i = 0; i < texto.length; i++) {
              if (numeros.indexOf(texto.charAt(i), 0) !== -1) {
                return 1;
              }
            }

            return 0;
          }
        }, {
          key: "tiene_letras",
          value: function tiene_letras(texto) {
            var letras = 'abcdefghyjklmnñopqrstuvwxyz';
            var i;
            texto = texto.toLowerCase();

            for (i = 0; i < texto.length; i++) {
              if (letras.indexOf(texto.charAt(i), 0) !== -1) {
                return 1;
              }
            }

            return 0;
          }
        }, {
          key: "tiene_minusculas",
          value: function tiene_minusculas(texto) {
            var letras = 'abcdefghyjklmnñopqrstuvwxyz';
            var i;

            for (i = 0; i < texto.length; i++) {
              if (letras.indexOf(texto.charAt(i), 0) !== -1) {
                return 1;
              }
            }

            return 0;
          }
        }, {
          key: "tiene_mayusculas",
          value: function tiene_mayusculas(texto) {
            var letras_mayusculas = 'ABCDEFGHYJKLMNÑOPQRSTUVWXYZ';
            var i;

            for (i = 0; i < texto.length; i++) {
              if (letras_mayusculas.indexOf(texto.charAt(i), 0) !== -1) {
                return 1;
              }
            }

            return 0;
          }
        }, {
          key: "nombre",
          get: function get() {
            return this.changeForm.get('nombre');
          }
        }, {
          key: "usuario",
          get: function get() {
            return this.changeForm.get('usuario');
          }
        }, {
          key: "password",
          get: function get() {
            return this.changeForm.get('password');
          }
        }, {
          key: "confirmPassword",
          get: function get() {
            return this.changeForm.get('confirmPassword');
          }
        }]);

        return ResetPasswordPage;
      }();

      ResetPasswordPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
        }, {
          type: src_app_services_user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"]
        }, {
          type: src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"]
        }];
      };

      ResetPasswordPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-reset-password',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./reset-password.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/reset-password/reset-password.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./reset-password.page.scss */
        "./src/app/pages/reset-password/reset-password.page.scss"))["default"]]
      })], ResetPasswordPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-reset-password-reset-password-module-es5.js.map