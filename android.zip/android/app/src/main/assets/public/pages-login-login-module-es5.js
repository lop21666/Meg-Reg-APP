(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-login-login-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/components/modal-contact/modal-contact.component.html":
    /*!*************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/modal-contact/modal-contact.component.html ***!
      \*************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppComponentsModalContactModalContactComponentHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\" color=\"dark\">\n        <ion-icon slot=\"start\" name=\"arrow-back-outline\" color=\"primary\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Contacto Soporte</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen>\n  <form (ngSubmit)=\"contact()\" [formGroup]=\"contactForm\">\n  <ion-list mode=\"md\">\n    <h5 class=\"ion-padding\">Nombre</h5>\n    <ion-item mode=\"md\">\n      <ion-input placeholder=\"Nombre*\" clearOnEdit=\"true\" clearInput formControlName=\"nombre\"></ion-input>\n      <ion-icon name=\"person-circle-outline\" slot=\"start\"></ion-icon>\n    </ion-item>\n    <div class=\"errors-contact\" *ngIf=\"nombre.invalid && (nombre.dirty || nombre.touched)\">\n      <span *ngIf=\"nombre.errors.required\">\n        <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n      </span>\n    </div>\n    <h5 class=\"ion-padding\">Dirección de email</h5>\n    <ion-item mode=\"md\">\n      <ion-input placeholder=\"Email*\" clearOnEdit=\"true\" clearInput formControlName=\"mail\"></ion-input>\n      <ion-icon name=\"mail-open-outline\" slot=\"start\"></ion-icon>\n    </ion-item>\n    <div class=\"errors-contact\" *ngIf=\"mail.invalid && (mail.dirty || mail.touched)\">\n      <span *ngIf=\"mail.errors.required\">\n        <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n      </span>\n      <span *ngIf=\"(mail.dirty || mail.touched) && mail.invalid && mail.errors.pattern\">\n        <ion-label class=\"error-container\">Enter an email valid</ion-label>\n      </span>\n    </div>\n    <h5 class=\"ion-padding\">Asunto del correo</h5>\n    <ion-item mode=\"md\">\n      <ion-input placeholder=\"Asunto*\" clearOnEdit=\"true\" clearInput formControlName=\"subject\"></ion-input>\n      <ion-icon name=\"bookmark-outline\" slot=\"start\"></ion-icon>\n    </ion-item>\n    <div class=\"errors-contact\" *ngIf=\"subject.invalid && (subject.dirty || subject.touched)\">\n      <span *ngIf=\"subject.errors.required\">\n        <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n      </span>\n    </div>\n    <h5 class=\"ion-padding\">Tu mensaje</h5>\n    <ion-item mode=\"md\">\n      <ion-textarea rows=\"10\" placeholder=\"Mensaje...\" clearOnEdit=\"true\" clearInput formControlName=\"msj\"></ion-textarea>\n      <ion-icon name=\"chatbox-ellipses-outline\" slot=\"start\"></ion-icon>\n    </ion-item>\n    <div class=\"errors-contact\" *ngIf=\"msj.invalid && (msj.dirty || msj.touched)\">\n      <span *ngIf=\"msj.errors.required\">\n        <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n      </span>\n    </div>\n  </ion-list>\n\n  <div class=\"container\">\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n        <ion-button expand=\"block\" class=\"button-1\" [disabled]=\"!contactForm.valid\" type=\"submit\">Enviar\n          <ion-icon slot=\"start\" color=\"white\" name=\"send-outline\"></ion-icon>\n        </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n</form>\n</ion-content>\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-login/popover-login.component.html":
    /*!*************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-login/popover-login.component.html ***!
      \*************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppComponentsPopoverLoginPopoverLoginComponentHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list>\n  <ion-item *ngFor=\"let item of items\" (click)=\"onClick(item)\">\n    <ion-icon slot=\"start\" name=\"{{item.icono}}\"></ion-icon>\n    <ion-label>{{item.nombre}}</ion-label>\n  </ion-item>\n</ion-list>\n\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html":
    /*!***********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html ***!
      \***********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesLoginLoginPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Iniciar Sesión</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"presentPopover( $event )\" fill=\"clear\">\n        <ion-icon slot=\"icon-only\" name=\"ellipsis-vertical-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"container\">\n    <div class=\"header\">\n    </div>\n    <ion-card class=\"body\">\n      <div class=\"img\">\n        <img src=\"../../../assets/images/elmarqrS.png\">\n      </div>\n      <form (ngSubmit)=\"login()\" [formGroup]=\"loginForm\">\n        <ion-list>\n          <ion-item mode=\"md\">\n            <ion-icon slot=\"start\" name=\"person-circle-outline\"></ion-icon>\n            <ion-input placeholder=\"User\" type=\"name\" clearOnEdit=\"true\" clearInput formControlName=\"nombre\">\n            </ion-input>\n          </ion-item>\n          <div class=\"errors\" *ngIf=\"nombre.invalid && (nombre.dirty || nombre.touched)\">\n            <span *ngIf=\"nombre.errors.required\">\n              <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n            </span>\n          </div>\n          <ion-item mode=\"md\">\n            <ion-icon slot=\"start\" name=\"lock-open\"></ion-icon>\n            <ion-input placeholder=\"Password\" type=\"password\" clearOnEdit=\"true\" clearInput formControlName=\"password\">\n            </ion-input>\n          </ion-item>\n          <div class=\"errors\" *ngIf=\"password.invalid && (password.dirty || password.touched)\">\n            <span *ngIf=\"password.errors.required\">\n              <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n            </span>\n          </div>\n        </ion-list>\n        <ion-grid>\n          <ion-row>\n            <ion-col>\n              <ion-button expand=\"block\" class=\"button-1\" type=\"submit\" [disabled]=\"!loginForm.valid\">Entrar\n                <ion-icon slot=\"start\" color=\"white\" name=\"enter-outline\"></ion-icon>\n              </ion-button>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </form>\n    </ion-card>\n  </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/components/components.module.ts":
    /*!*************************************************!*\
      !*** ./src/app/components/components.module.ts ***!
      \*************************************************/

    /*! exports provided: ComponentsModule */

    /***/
    function srcAppComponentsComponentsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ComponentsModule", function () {
        return ComponentsModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _popover_login_popover_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./popover-login/popover-login.component */
      "./src/app/components/popover-login/popover-login.component.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _modal_contact_modal_contact_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./modal-contact/modal-contact.component */
      "./src/app/components/modal-contact/modal-contact.component.ts");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _popover_perfil_popover_perfil_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./popover-perfil/popover-perfil.component */
      "./src/app/components/popover-perfil/popover-perfil.component.ts");
      /* harmony import */


      var _details_modal_details_modal_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./details-modal/details-modal.component */
      "./src/app/components/details-modal/details-modal.component.ts");

      var ComponentsModule = function ComponentsModule() {
        _classCallCheck(this, ComponentsModule);
      };

      ComponentsModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_popover_login_popover_login_component__WEBPACK_IMPORTED_MODULE_3__["PopoverLoginComponent"], _modal_contact_modal_contact_component__WEBPACK_IMPORTED_MODULE_5__["ModalContactComponent"], _popover_perfil_popover_perfil_component__WEBPACK_IMPORTED_MODULE_7__["PopoverPerfilComponent"], _details_modal_details_modal_component__WEBPACK_IMPORTED_MODULE_8__["DetailsModalComponent"]],
        exports: [_popover_login_popover_login_component__WEBPACK_IMPORTED_MODULE_3__["PopoverLoginComponent"], _modal_contact_modal_contact_component__WEBPACK_IMPORTED_MODULE_5__["ModalContactComponent"], _popover_perfil_popover_perfil_component__WEBPACK_IMPORTED_MODULE_7__["PopoverPerfilComponent"], _details_modal_details_modal_component__WEBPACK_IMPORTED_MODULE_8__["DetailsModalComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"]]
      })], ComponentsModule);
      /***/
    },

    /***/
    "./src/app/components/modal-contact/modal-contact.component.scss":
    /*!***********************************************************************!*\
      !*** ./src/app/components/modal-contact/modal-contact.component.scss ***!
      \***********************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppComponentsModalContactModalContactComponentScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-item {\n  --border-color: transparent !important;\n  --background: #F7F7F6;\n  border-radius: 14px;\n  margin-left: 4%;\n  margin-right: 4%;\n}\n\nion-list {\n  background-color: #FFF;\n}\n\nion-toolbar {\n  --background: #F4F3EF;\n}\n\nion-title {\n  color: #508bfa;\n}\n\n.button-1 {\n  --background:rgb(80, 139, 250);\n  margin-top: 20%;\n}\n\n.container {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n\nion-icon {\n  color: #508bfa;\n}\n\nh5 {\n  color: #2471a3;\n}\n\n.error-container {\n  color: #66615B;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9tb2RhbC1jb250YWN0L21vZGFsLWNvbnRhY3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxzQ0FBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFDSjs7QUFFQTtFQUNJLHNCQUFBO0FBQ0o7O0FBRUE7RUFDSSxxQkFBQTtBQUNKOztBQUVBO0VBQ0ksY0FBQTtBQUNKOztBQUVBO0VBQ0ksOEJBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBQ0o7O0FBRUE7RUFDSSxjQUFBO0FBQ0o7O0FBRUE7RUFDSSxjQUFBO0FBQ0o7O0FBRUE7RUFDSSxjQUFBO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL21vZGFsLWNvbnRhY3QvbW9kYWwtY29udGFjdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVtIHtcclxuICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRjdGN0Y2O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTRweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA0JTtcclxuICAgIG1hcmdpbi1yaWdodDogNCU7XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGRkY7XHJcbn1cclxuXHJcbmlvbi10b29sYmFye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRjRGM0VGO1xyXG59XHJcblxyXG5pb24tdGl0bGV7XHJcbiAgICBjb2xvcjogcmdiKDgwLCAxMzksIDI1MCk7XHJcbn1cclxuXHJcbi5idXR0b24tMXtcclxuICAgIC0tYmFja2dyb3VuZDpyZ2IoODAsIDEzOSwgMjUwKTtcclxuICAgIG1hcmdpbi10b3A6IDIwJTsgXHJcbn1cclxuXHJcbi5jb250YWluZXIge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbmlvbi1pY29uIHtcclxuICAgIGNvbG9yOiByZ2IoODAsIDEzOSwgMjUwKTtcclxufVxyXG5cclxuaDUge1xyXG4gICAgY29sb3I6IHJnYigzNiwgMTEzLCAxNjMpOyBcclxufVxyXG5cclxuLmVycm9yLWNvbnRhaW5lcntcclxuICAgIGNvbG9yOiAjNjY2MTVCO1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/components/modal-contact/modal-contact.component.ts":
    /*!*********************************************************************!*\
      !*** ./src/app/components/modal-contact/modal-contact.component.ts ***!
      \*********************************************************************/

    /*! exports provided: ModalContactComponent */

    /***/
    function srcAppComponentsModalContactModalContactComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ModalContactComponent", function () {
        return ModalContactComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../services/user.service */
      "./src/app/services/user.service.ts");
      /* harmony import */


      var _services_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../services/alert.service */
      "./src/app/services/alert.service.ts");

      var ModalContactComponent = /*#__PURE__*/function () {
        function ModalContactComponent(modalController, userService, alertService) {
          _classCallCheck(this, ModalContactComponent);

          this.modalController = modalController;
          this.userService = userService;
          this.alertService = alertService;
          this.pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          this.contactForm = this.createFormGroup();
        }

        _createClass(ModalContactComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "createFormGroup",
          value: function createFormGroup() {
            return new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
              mail: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(this.pattern)]),
              subject: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
              msj: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
              nombre: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
            });
          }
        }, {
          key: "back",
          value: function back() {
            this.modalController.dismiss();
          }
        }, {
          key: "contact",
          value: function contact() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.userService.contactAdmin(this.contactForm.value.nombre, this.contactForm.value.mail, this.contactForm.value.subject, this.contactForm.value.msj);

                    case 2:
                      _context.sent.subscribe(function (resp) {
                        if (resp.status) {
                          var message = resp.message;

                          _this.alertService.presentAlert(message);

                          _this.contactForm.reset();

                          _this.modalController.dismiss();
                        } else {
                          var _message = resp.message;

                          _this.alertService.presentAlert(_message);
                        }
                      });

                    case 3:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "mail",
          get: function get() {
            return this.contactForm.get('mail');
          }
        }, {
          key: "subject",
          get: function get() {
            return this.contactForm.get('subject');
          }
        }, {
          key: "msj",
          get: function get() {
            return this.contactForm.get('msj');
          }
        }, {
          key: "nombre",
          get: function get() {
            return this.contactForm.get('nombre');
          }
        }]);

        return ModalContactComponent;
      }();

      ModalContactComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
        }, {
          type: _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"]
        }, {
          type: _services_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"]
        }];
      };

      ModalContactComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-modal-contact',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./modal-contact.component.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/components/modal-contact/modal-contact.component.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./modal-contact.component.scss */
        "./src/app/components/modal-contact/modal-contact.component.scss"))["default"]]
      })], ModalContactComponent);
      /***/
    },

    /***/
    "./src/app/components/popover-login/popover-login.component.scss":
    /*!***********************************************************************!*\
      !*** ./src/app/components/popover-login/popover-login.component.scss ***!
      \***********************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppComponentsPopoverLoginPopoverLoginComponentScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcG9wb3Zlci1sb2dpbi9wb3BvdmVyLWxvZ2luLmNvbXBvbmVudC5zY3NzIn0= */";
      /***/
    },

    /***/
    "./src/app/components/popover-login/popover-login.component.ts":
    /*!*********************************************************************!*\
      !*** ./src/app/components/popover-login/popover-login.component.ts ***!
      \*********************************************************************/

    /*! exports provided: PopoverLoginComponent */

    /***/
    function srcAppComponentsPopoverLoginPopoverLoginComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PopoverLoginComponent", function () {
        return PopoverLoginComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _modal_contact_modal_contact_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../modal-contact/modal-contact.component */
      "./src/app/components/modal-contact/modal-contact.component.ts");

      var PopoverLoginComponent = /*#__PURE__*/function () {
        function PopoverLoginComponent(popoverCtrl, router, modalController) {
          _classCallCheck(this, PopoverLoginComponent);

          this.popoverCtrl = popoverCtrl;
          this.router = router;
          this.modalController = modalController;
          this.items = [{
            nombre: 'Contactar al administrador',
            icono: 'mail-unread-outline'
          }, {
            nombre: 'Recuperar contraseña',
            icono: 'key-outline'
          }];
        }

        _createClass(PopoverLoginComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "onClick",
          value: function onClick(item) {
            if (item.nombre === 'Contactar al administrador') {
              this.mostrarModal();
              this.popoverCtrl.dismiss();
            } else {
              this.router.navigateByUrl('/cambiar-password');
              this.popoverCtrl.dismiss();
            }
          }
        }, {
          key: "mostrarModal",
          value: function mostrarModal() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var modal;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.modalController.create({
                        component: _modal_contact_modal_contact_component__WEBPACK_IMPORTED_MODULE_4__["ModalContactComponent"],
                        cssClass: 'with-top',
                        componentProps: {
                          items: this.items
                        }
                      });

                    case 2:
                      modal = _context2.sent;
                      _context2.next = 5;
                      return modal.present();

                    case 5:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return PopoverLoginComponent;
      }();

      PopoverLoginComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
        }];
      };

      PopoverLoginComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-popover-login',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./popover-login.component.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-login/popover-login.component.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./popover-login.component.scss */
        "./src/app/components/popover-login/popover-login.component.scss"))["default"]]
      })], PopoverLoginComponent);
      /***/
    },

    /***/
    "./src/app/pages/login/login-routing.module.ts":
    /*!*****************************************************!*\
      !*** ./src/app/pages/login/login-routing.module.ts ***!
      \*****************************************************/

    /*! exports provided: LoginPageRoutingModule */

    /***/
    function srcAppPagesLoginLoginRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function () {
        return LoginPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./login.page */
      "./src/app/pages/login/login.page.ts");

      var routes = [{
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
      }];

      var LoginPageRoutingModule = function LoginPageRoutingModule() {
        _classCallCheck(this, LoginPageRoutingModule);
      };

      LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], LoginPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/login/login.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/pages/login/login.module.ts ***!
      \*********************************************/

    /*! exports provided: LoginPageModule */

    /***/
    function srcAppPagesLoginLoginModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LoginPageModule", function () {
        return LoginPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./login-routing.module */
      "./src/app/pages/login/login-routing.module.ts");
      /* harmony import */


      var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./login.page */
      "./src/app/pages/login/login.page.ts");
      /* harmony import */


      var _components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../components/components.module */
      "./src/app/components/components.module.ts");

      var LoginPageModule = function LoginPageModule() {
        _classCallCheck(this, LoginPageModule);
      };

      LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"], _components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
      })], LoginPageModule);
      /***/
    },

    /***/
    "./src/app/pages/login/login.page.scss":
    /*!*********************************************!*\
      !*** ./src/app/pages/login/login.page.scss ***!
      \*********************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesLoginLoginPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  --background:linear-gradient(\n      rgba(0, 0, 0, 0.1),\n      rgba(0, 0, 0, 0.1)\n      ), url('fondo.jpg') no-repeat center center / cover;\n}\n\n.container {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n\n.header {\n  flex: 1;\n  justify-content: center;\n  text-align: center;\n  padding-top: 50px;\n  padding-bottom: 70px;\n}\n\n.img {\n  height: 47%;\n  width: 47%;\n  margin-left: 27%;\n}\n\nh2 {\n  color: #508bfa;\n}\n\n.body {\n  padding-top: 6%;\n  padding-bottom: 6%;\n  padding-right: 3%;\n  padding-left: 3%;\n  background-color: #FFF;\n}\n\nion-item {\n  --border-color: transparent !important;\n  --background: #F7F7F6;\n  border-radius: 14px;\n  margin-bottom: 14px;\n  margin-top: 14px;\n}\n\nion-icon {\n  color: #508bfa;\n}\n\nion-input {\n  --color: black;\n}\n\nion-list {\n  background-color: #FFF;\n  padding-top: 7%;\n}\n\n.button-1 {\n  --background: rgb(80, 139, 250);\n  margin-top: 10%;\n}\n\nion-toolbar {\n  --background: white;\n}\n\n.icono {\n  color: white;\n}\n\nion-title {\n  color: #508bfa;\n}\n\n.error-container {\n  color: #66615B;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbG9naW4vbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0k7Ozt5REFBQTtBQUlKOztBQUVBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUNBOztBQUVBO0VBQ0EsT0FBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0FBQ0E7O0FBRUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0FBQ0E7O0FBRUE7RUFDQSxjQUFBO0FBQ0E7O0FBRUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Esc0JBQUE7QUFDQTs7QUFFQTtFQUNBLHNDQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFDQTs7QUFFQTtFQUNBLGNBQUE7QUFDQTs7QUFFQTtFQUNBLGNBQUE7QUFDQTs7QUFFQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtBQUNBOztBQUVBO0VBQ0EsK0JBQUE7RUFDQSxlQUFBO0FBQ0E7O0FBRUE7RUFDQSxtQkFBQTtBQUNBOztBQUVBO0VBQ0EsWUFBQTtBQUNBOztBQUVBO0VBQ0EsY0FBQTtBQUNBOztBQUVBO0VBQ0EsY0FBQTtBQUNBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KFxyXG4gICAgICAgIHJnYmEoMCwgMCwgMCwgMC4xKSxcclxuICAgICAgICByZ2JhKDAsIDAsIDAsIDAuMSlcclxuICAgICAgICApLCB1cmwoJy4uLy4uLy4uL2Fzc2V0cy9pbWFnZXMvZm9uZG8uanBnJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxufVxyXG5cclxuLmNvbnRhaW5lciB7XHJcbmRpc3BsYXk6IGZsZXg7XHJcbmZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbmp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5hbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uaGVhZGVyIHtcclxuZmxleDogMTtcclxuanVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbnRleHQtYWxpZ246IGNlbnRlcjtcclxucGFkZGluZy10b3A6IDUwcHg7XHJcbnBhZGRpbmctYm90dG9tOiA3MHB4O1xyXG59XHJcblxyXG4uaW1nIHtcclxuaGVpZ2h0OiA0NyU7XHJcbndpZHRoOiA0NyU7XHJcbm1hcmdpbi1sZWZ0OiAyNyU7XHJcbn1cclxuXHJcbmgyIHtcclxuY29sb3I6IHJnYig4MCwgMTM5LCAyNTApO1xyXG59XHJcblxyXG4uYm9keSB7XHJcbnBhZGRpbmctdG9wOiA2JTtcclxucGFkZGluZy1ib3R0b206IDYlO1xyXG5wYWRkaW5nLXJpZ2h0OiAzJTtcclxucGFkZGluZy1sZWZ0OiAzJTtcclxuYmFja2dyb3VuZC1jb2xvcjogI0ZGRjtcclxufVxyXG5cclxuaW9uLWl0ZW0ge1xyXG4tLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuLS1iYWNrZ3JvdW5kOiAjRjdGN0Y2O1xyXG5ib3JkZXItcmFkaXVzOiAxNHB4O1xyXG5tYXJnaW4tYm90dG9tOiAxNHB4O1xyXG5tYXJnaW4tdG9wOiAxNHB4O1xyXG59XHJcblxyXG5pb24taWNvbiB7XHJcbmNvbG9yOiByZ2IoODAsIDEzOSwgMjUwKTtcclxufVxyXG5cclxuaW9uLWlucHV0IHtcclxuLS1jb2xvcjogYmxhY2s7XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuYmFja2dyb3VuZC1jb2xvcjogI0ZGRjtcclxucGFkZGluZy10b3A6IDclO1xyXG59XHJcblxyXG4uYnV0dG9uLTF7XHJcbi0tYmFja2dyb3VuZDogcmdiKDgwLCAxMzksIDI1MCk7XHJcbm1hcmdpbi10b3A6IDEwJTtcclxufVxyXG5cclxuaW9uLXRvb2xiYXJ7XHJcbi0tYmFja2dyb3VuZDogd2hpdGU7IFxyXG59XHJcblxyXG4uaWNvbm97XHJcbmNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuaW9uLXRpdGxle1xyXG5jb2xvcjogcmdiKDgwLCAxMzksIDI1MCk7XHJcbn1cclxuXHJcbi5lcnJvci1jb250YWluZXJ7XHJcbmNvbG9yOiAjNjY2MTVCO1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/login/login.page.ts":
    /*!*******************************************!*\
      !*** ./src/app/pages/login/login.page.ts ***!
      \*******************************************/

    /*! exports provided: LoginPage */

    /***/
    function srcAppPagesLoginLoginPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LoginPage", function () {
        return LoginPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _components_popover_login_popover_login_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../components/popover-login/popover-login.component */
      "./src/app/components/popover-login/popover-login.component.ts");
      /* harmony import */


      var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../services/user.service */
      "./src/app/services/user.service.ts");
      /* harmony import */


      var _services_alert_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../services/alert.service */
      "./src/app/services/alert.service.ts");

      var LoginPage = /*#__PURE__*/function () {
        function LoginPage(popoverCtrl, navCtrl, userService, alertService) {
          _classCallCheck(this, LoginPage);

          this.popoverCtrl = popoverCtrl;
          this.navCtrl = navCtrl;
          this.userService = userService;
          this.alertService = alertService;
          this.sliderOpts = {
            allowSlidePrev: false,
            allowSlideNext: false
          };
          this.loginForm = this.createFormGroup();
        }

        _createClass(LoginPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "createFormGroup",
          value: function createFormGroup() {
            return new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
              nombre: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
              password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
            });
          }
        }, {
          key: "login",
          value: function login() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var valid, message;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.userService.login(this.loginForm.value.nombre, this.loginForm.value.password);

                    case 2:
                      valid = _context3.sent;

                      if (valid) {
                        this.navCtrl.navigateRoot('/tabs', {
                          animated: true
                        });
                      } else {
                        message = 'Usuario y/o Contraseña son incorrectos';
                        this.alertService.presentToast(message, 'danger', 2500);
                        this.loginForm.reset();
                      }

                    case 4:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "presentPopover",
          value: function presentPopover(ev) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var popover;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.popoverCtrl.create({
                        component: _components_popover_login_popover_login_component__WEBPACK_IMPORTED_MODULE_4__["PopoverLoginComponent"],
                        event: ev,
                        translucent: false,
                        cssClass: 'pop-Over',
                        backdropDismiss: true
                      });

                    case 2:
                      popover = _context4.sent;
                      _context4.next = 5;
                      return popover.present();

                    case 5:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "nombre",
          get: function get() {
            return this.loginForm.get('nombre');
          }
        }, {
          key: "password",
          get: function get() {
            return this.loginForm.get('password');
          }
        }]);

        return LoginPage;
      }();

      LoginPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
        }, {
          type: _services_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"]
        }, {
          type: _services_alert_service__WEBPACK_IMPORTED_MODULE_6__["AlertService"]
        }];
      };

      LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./login.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./login.page.scss */
        "./src/app/pages/login/login.page.scss"))["default"]]
      })], LoginPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-login-login-module-es5.js.map