(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-cambiar-password-cambiar-password-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cambiar-password/cambiar-password.page.html":
    /*!*********************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cambiar-password/cambiar-password.page.html ***!
      \*********************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesCambiarPasswordCambiarPasswordPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\" color=\"primary\">Atrás\n        <ion-icon slot=\"start\" name=\"arrow-back-outline\" color=\"primary\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Recuperar Contraseña</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"container\">\n    <div class=\"header\">\n    </div>\n    <ion-card class=\"body\">\n      <div class=\"img\">\n        <img src=\"https://demo.bpm.gt//CONFIG/img/logo_largo.png\">\n      </div>\n      <form (ngSubmit)=\"resetPass()\" [formGroup]=\"passForm\">   \n      <ion-list>\n        <ion-item mode=\"md\">\n          <ion-icon slot=\"start\" name=\"at-outline\"></ion-icon>\n          <ion-input placeholder=\"Email*\" type=\"name\" clearOnEdit=\"true\" clearInput formControlName=\"mail\"></ion-input>\n        </ion-item>\n        <div class=\"errors\" *ngIf=\"mail.invalid && (mail.dirty || mail.touched)\">\n          <span *ngIf=\"mail.errors.required\">\n            <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n          </span>\n          <span *ngIf=\"(mail.dirty || mail.touched) && mail.invalid && mail.errors.pattern\">\n            <ion-label class=\"error-container\">Enter an email valid</ion-label>\n          </span>\n        </div>\n      </ion-list>\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n          <ion-button expand=\"block\" class=\"button-1\" [disabled]=\"!passForm.valid\" type=\"submit\">Enviar\n            <ion-icon slot=\"start\" color=\"white\" name=\"send-outline\"></ion-icon>\n          </ion-button>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </form> \n    </ion-card>\n  </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/pages/cambiar-password/cambiar-password-routing.module.ts":
    /*!***************************************************************************!*\
      !*** ./src/app/pages/cambiar-password/cambiar-password-routing.module.ts ***!
      \***************************************************************************/

    /*! exports provided: CambiarPasswordPageRoutingModule */

    /***/
    function srcAppPagesCambiarPasswordCambiarPasswordRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CambiarPasswordPageRoutingModule", function () {
        return CambiarPasswordPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _cambiar_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./cambiar-password.page */
      "./src/app/pages/cambiar-password/cambiar-password.page.ts");

      var routes = [{
        path: '',
        component: _cambiar_password_page__WEBPACK_IMPORTED_MODULE_3__["CambiarPasswordPage"]
      }];

      var CambiarPasswordPageRoutingModule = function CambiarPasswordPageRoutingModule() {
        _classCallCheck(this, CambiarPasswordPageRoutingModule);
      };

      CambiarPasswordPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CambiarPasswordPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/cambiar-password/cambiar-password.module.ts":
    /*!*******************************************************************!*\
      !*** ./src/app/pages/cambiar-password/cambiar-password.module.ts ***!
      \*******************************************************************/

    /*! exports provided: CambiarPasswordPageModule */

    /***/
    function srcAppPagesCambiarPasswordCambiarPasswordModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CambiarPasswordPageModule", function () {
        return CambiarPasswordPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _cambiar_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./cambiar-password-routing.module */
      "./src/app/pages/cambiar-password/cambiar-password-routing.module.ts");
      /* harmony import */


      var _cambiar_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./cambiar-password.page */
      "./src/app/pages/cambiar-password/cambiar-password.page.ts");

      var CambiarPasswordPageModule = function CambiarPasswordPageModule() {
        _classCallCheck(this, CambiarPasswordPageModule);
      };

      CambiarPasswordPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _cambiar_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["CambiarPasswordPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
        declarations: [_cambiar_password_page__WEBPACK_IMPORTED_MODULE_6__["CambiarPasswordPage"]]
      })], CambiarPasswordPageModule);
      /***/
    },

    /***/
    "./src/app/pages/cambiar-password/cambiar-password.page.scss":
    /*!*******************************************************************!*\
      !*** ./src/app/pages/cambiar-password/cambiar-password.page.scss ***!
      \*******************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesCambiarPasswordCambiarPasswordPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  --offset-top: 0px;\n  --offset-bottom: 0px;\n  --background: #F7F7F6;\n  --color: #FFF;\n}\n\n.container {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n\n.header {\n  flex: 1;\n  justify-content: center;\n  text-align: center;\n  padding-top: 50px;\n  padding-bottom: 70px;\n}\n\n.img {\n  height: 67%;\n  width: 67%;\n  margin-left: 15%;\n}\n\nh2 {\n  color: #508bfa;\n}\n\n.body {\n  padding-top: 6%;\n  padding-bottom: 6%;\n  padding-right: 3%;\n  padding-left: 3%;\n  background-color: #FFF;\n}\n\nion-item {\n  --border-color: transparent !important;\n  --background: #F7F7F6;\n  border-radius: 14px;\n  margin-bottom: 14px;\n  margin-top: 14px;\n}\n\nion-icon {\n  color: #508bfa;\n}\n\nion-input {\n  --color: black;\n}\n\nion-list {\n  background-color: #FFF;\n  padding-top: 7%;\n}\n\n.button-1 {\n  --background:rgb(80, 139, 250);\n  margin-top: 10%;\n}\n\nion-toolbar {\n  --background: white;\n}\n\n.icono {\n  color: white;\n}\n\nion-title {\n  color: #508bfa;\n}\n\n.error-container {\n  color: #66615B;\n}\n\nion-content {\n  --background:linear-gradient(\n      rgba(0, 0, 0, 0.1),\n      rgba(0, 0, 0, 0.1)\n      ), url('fondo.jpg') no-repeat center center / cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2FtYmlhci1wYXNzd29yZC9jYW1iaWFyLXBhc3N3b3JkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxxQkFBQTtFQUNBLGFBQUE7QUFDSjs7QUFHQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFBSjs7QUFHQTtFQUNJLE9BQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtBQUFKOztBQUdBO0VBQ0ksV0FBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtBQUFKOztBQUdBO0VBQ0ksY0FBQTtBQUFKOztBQUdBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0FBQUo7O0FBR0E7RUFDSSxzQ0FBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBQUo7O0FBR0E7RUFDSSxjQUFBO0FBQUo7O0FBR0E7RUFDSSxjQUFBO0FBQUo7O0FBR0E7RUFDSSxzQkFBQTtFQUNBLGVBQUE7QUFBSjs7QUFHQTtFQUNJLDhCQUFBO0VBQ0EsZUFBQTtBQUFKOztBQUdBO0VBQ0ksbUJBQUE7QUFBSjs7QUFHQTtFQUNJLFlBQUE7QUFBSjs7QUFHQTtFQUNJLGNBQUE7QUFBSjs7QUFHQTtFQUNJLGNBQUE7QUFBSjs7QUFHQTtFQUNJOzs7eURBQUE7QUFHSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2NhbWJpYXItcGFzc3dvcmQvY2FtYmlhci1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgICAtLW9mZnNldC10b3A6IDBweDtcclxuICAgIC0tb2Zmc2V0LWJvdHRvbTogMHB4O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRjdGN0Y2O1xyXG4gICAgLS1jb2xvcjogI0ZGRjtcclxuXHJcbn1cclxuXHJcbi5jb250YWluZXIge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5oZWFkZXIge1xyXG4gICAgZmxleDogMTtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZy10b3A6IDUwcHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNzBweDtcclxufVxyXG5cclxuLmltZyB7XHJcbiAgICBoZWlnaHQ6IDY3JTtcclxuICAgIHdpZHRoOiA2NyU7XHJcbiAgICBtYXJnaW4tbGVmdDogMTUlO1xyXG59XHJcblxyXG5oMiB7XHJcbiAgICBjb2xvcjogcmdiKDgwLCAxMzksIDI1MCk7XHJcbn1cclxuXHJcbi5ib2R5IHtcclxuICAgIHBhZGRpbmctdG9wOiA2JTtcclxuICAgIHBhZGRpbmctYm90dG9tOiA2JTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDMlO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAzJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGRkY7XHJcbn1cclxuXHJcbmlvbi1pdGVtIHtcclxuICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRjdGN0Y2O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTRweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDE0cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxNHB4O1xyXG59XHJcblxyXG5pb24taWNvbiB7XHJcbiAgICBjb2xvcjogcmdiKDgwLCAxMzksIDI1MCk7XHJcbn1cclxuXHJcbmlvbi1pbnB1dCB7XHJcbiAgICAtLWNvbG9yOiBibGFjaztcclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0ZGRjtcclxuICAgIHBhZGRpbmctdG9wOiA3JTtcclxufVxyXG5cclxuLmJ1dHRvbi0xe1xyXG4gICAgLS1iYWNrZ3JvdW5kOnJnYig4MCwgMTM5LCAyNTApOyBcclxuICAgIG1hcmdpbi10b3A6IDEwJTtcclxufVxyXG5cclxuaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlOyBcclxufVxyXG5cclxuLmljb25ve1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG5pb24tdGl0bGV7XHJcbiAgICBjb2xvcjogcmdiKDgwLCAxMzksIDI1MCk7XHJcbn1cclxuXHJcbi5lcnJvci1jb250YWluZXJ7XHJcbiAgICBjb2xvcjogIzY2NjE1QjtcclxufVxyXG5cclxuaW9uLWNvbnRlbnR7XHJcbiAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KFxyXG4gICAgICAgIHJnYmEoMCwgMCwgMCwgMC4xKSxcclxuICAgICAgICByZ2JhKDAsIDAsIDAsIDAuMSlcclxuICAgICAgICApLCB1cmwoJy4uLy4uLy4uL2Fzc2V0cy9pbWFnZXMvZm9uZG8uanBnJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/cambiar-password/cambiar-password.page.ts":
    /*!*****************************************************************!*\
      !*** ./src/app/pages/cambiar-password/cambiar-password.page.ts ***!
      \*****************************************************************/

    /*! exports provided: CambiarPasswordPage */

    /***/
    function srcAppPagesCambiarPasswordCambiarPasswordPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CambiarPasswordPage", function () {
        return CambiarPasswordPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../services/user.service */
      "./src/app/services/user.service.ts");
      /* harmony import */


      var _services_alert_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../services/alert.service */
      "./src/app/services/alert.service.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var CambiarPasswordPage = /*#__PURE__*/function () {
        function CambiarPasswordPage(navCtrl, userService, alertService) {
          _classCallCheck(this, CambiarPasswordPage);

          this.navCtrl = navCtrl;
          this.userService = userService;
          this.alertService = alertService;
          this.pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          this.passForm = this.createFormGroup();
        }

        _createClass(CambiarPasswordPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "createFormGroup",
          value: function createFormGroup() {
            return new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
              mail: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(this.pattern)])
            });
          }
        }, {
          key: "back",
          value: function back() {
            this.navCtrl.back({
              animated: true
            });
          }
        }, {
          key: "resetPass",
          value: function resetPass() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.userService.resetPassword(this.passForm.value.mail);

                    case 2:
                      _context.sent.subscribe(function (resp) {
                        if (resp.status) {
                          var message = resp.message;

                          _this.alertService.presentAlert(message);

                          _this.passForm.reset();
                        } else {
                          var _message = resp.message;

                          _this.alertService.presentAlert(_message);

                          _this.passForm.reset();
                        }
                      });

                    case 3:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "mail",
          get: function get() {
            return this.passForm.get('mail');
          }
        }]);

        return CambiarPasswordPage;
      }();

      CambiarPasswordPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
        }, {
          type: _services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"]
        }, {
          type: _services_alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"]
        }];
      };

      CambiarPasswordPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cambiar-password',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./cambiar-password.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cambiar-password/cambiar-password.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./cambiar-password.page.scss */
        "./src/app/pages/cambiar-password/cambiar-password.page.scss"))["default"]]
      })], CambiarPasswordPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-cambiar-password-cambiar-password-module-es5.js.map