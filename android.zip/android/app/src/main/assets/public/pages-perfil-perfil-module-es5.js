(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-perfil-perfil-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/perfil/perfil.page.html":
    /*!*************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/perfil/perfil.page.html ***!
      \*************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesPerfilPerfilPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\" color=\"light\">Atrás\n        <ion-icon slot=\"start\" name=\"arrow-back-outline\" color=\"light\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Perfil</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card *ngIf=\"!mostrarData\">\n    <ion-card-header>\n      <ion-skeleton-text animated class=\"skeleton-img\"></ion-skeleton-text>\n    </ion-card-header>\n    <ion-card-content>\n      <ion-skeleton-text animated class=\"avatar\"></ion-skeleton-text>\n      <ion-skeleton-text animated class=\"container-skeleton\" style=\"width: 60%\"></ion-skeleton-text>\n      <br>\n      <div *ngFor=\"let item of items\" class=\"margin-bottom\">\n        <ion-skeleton-text animated style=\"width: 15%\" class=\"margin\"></ion-skeleton-text>\n        <ion-skeleton-text animated style=\"width: 90%\" class=\"item-skeleton\"></ion-skeleton-text>\n      </div>\n      <br>\n      <ion-grid class=\"margin-top-menos\">\n        <ion-row>\n          <ion-col size=\"6\">\n            <ion-skeleton-text animated style=\"width: 90%\" class=\"button-skeleton\"></ion-skeleton-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-skeleton-text animated style=\"width: 90%\" class=\"button-skeleton\"></ion-skeleton-text>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n      <br>\n    </ion-card-content>\n  </ion-card>\n\n\n  <ion-card *ngIf=\"mostrarData\" class=\"animated-card fadeIn fast\">\n    <ion-card-header>\n      <ion-img src=\"../../../assets/images/elmarqr.png\" class=\"img animated fadeIn fast\"></ion-img>\n    </ion-card-header>\n    <ion-card-content>\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"3\"></ion-col>\n          <ion-col size=\"6\">\n            <ion-avatar class=\"avatar\">\n              <img [src]=\"urlFoto\">\n            </ion-avatar>\n          </ion-col>\n          <ion-col size=\"3\"></ion-col>\n        </ion-row>\n      </ion-grid>\n      <ion-card-title class=\"container\">{{perfilData.nombre}}</ion-card-title>\n      <form (ngSubmit)=\"editProfile()\" [formGroup]=\"profileForm\">\n        <ion-list>\n          <small>Nombre:*</small>\n          <ion-item mode=\"md\">\n            <ion-icon slot=\"start\" name=\"person-circle-outline\"></ion-icon>\n            <ion-input placeholder=\"User\" type=\"name\" clearOnEdit=\"true\" clearInput formControlName=\"nombre\">\n            </ion-input>\n          </ion-item>\n          <div class=\"errors\" *ngIf=\"nombre.invalid && (nombre.dirty || nombre.touched)\">\n            <span *ngIf=\"nombre.errors.required\">\n              <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n            </span>\n          </div>\n          <small>E-mail:*</small>\n          <ion-item mode=\"md\">\n            <ion-icon slot=\"start\" name=\"mail-open-outline\"></ion-icon>\n            <ion-input placeholder=\"Mail\" type=\"name\" clearOnEdit=\"true\" clearInput formControlName=\"mail\">\n            </ion-input>\n          </ion-item>\n          <div class=\"errors\" *ngIf=\"mail.invalid && (mail.dirty || mail.touched)\">\n            <span *ngIf=\"mail.errors.required\">\n              <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n            </span>\n            <span *ngIf=\"(mail.dirty || mail.touched) && mail.invalid && mail.errors.pattern\">\n              <ion-label class=\"error-container\">Enter an email valid</ion-label>\n            </span>\n          </div>\n          <small>Telefono:*</small>\n          <ion-item mode=\"md\">\n            <ion-icon slot=\"start\" name=\"call-sharp\"></ion-icon>\n            <ion-input placeholder=\"telefono\" type=\"name\" clearOnEdit=\"true\" clearInput formControlName=\"telefono\">\n            </ion-input>\n          </ion-item>\n          <div class=\"errors\" *ngIf=\"telefono.invalid && (telefono.dirty || telefono.touched)\">\n            <span *ngIf=\"telefono.errors.required\">\n              <ion-label class=\"error-container\">Este campo es requerido</ion-label>\n            </span>\n          </div>\n        </ion-list>\n        <ion-grid>\n          <br>\n          <ion-row>\n            <ion-col size=\"6\">\n              <ion-button expand=\"block\" class=\"button-clean\" fill=\"outline\" color=\"dark\" (click)=\"clean()\"\n                strong=\"true\">Limpiar\n                <ion-icon slot=\"start\" color=\"black\" name=\"close-circle-outline\"></ion-icon>\n              </ion-button>\n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-button expand=\"block\" class=\"button-save\" type=\"submit\" [disabled]=\"!profileForm.valid\"\n                strong=\"true\">Guardar\n                <ion-icon slot=\"start\" color=\"white\" name=\"save\"></ion-icon>\n              </ion-button>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </form>\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/pages/perfil/perfil-routing.module.ts":
    /*!*******************************************************!*\
      !*** ./src/app/pages/perfil/perfil-routing.module.ts ***!
      \*******************************************************/

    /*! exports provided: PerfilPageRoutingModule */

    /***/
    function srcAppPagesPerfilPerfilRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PerfilPageRoutingModule", function () {
        return PerfilPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _perfil_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./perfil.page */
      "./src/app/pages/perfil/perfil.page.ts");

      var routes = [{
        path: '',
        component: _perfil_page__WEBPACK_IMPORTED_MODULE_3__["PerfilPage"]
      }];

      var PerfilPageRoutingModule = function PerfilPageRoutingModule() {
        _classCallCheck(this, PerfilPageRoutingModule);
      };

      PerfilPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], PerfilPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/perfil/perfil.module.ts":
    /*!***********************************************!*\
      !*** ./src/app/pages/perfil/perfil.module.ts ***!
      \***********************************************/

    /*! exports provided: PerfilPageModule */

    /***/
    function srcAppPagesPerfilPerfilModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PerfilPageModule", function () {
        return PerfilPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _perfil_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./perfil-routing.module */
      "./src/app/pages/perfil/perfil-routing.module.ts");
      /* harmony import */


      var _perfil_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./perfil.page */
      "./src/app/pages/perfil/perfil.page.ts");

      var PerfilPageModule = function PerfilPageModule() {
        _classCallCheck(this, PerfilPageModule);
      };

      PerfilPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _perfil_routing_module__WEBPACK_IMPORTED_MODULE_5__["PerfilPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
        declarations: [_perfil_page__WEBPACK_IMPORTED_MODULE_6__["PerfilPage"]]
      })], PerfilPageModule);
      /***/
    },

    /***/
    "./src/app/pages/perfil/perfil.page.scss":
    /*!***********************************************!*\
      !*** ./src/app/pages/perfil/perfil.page.scss ***!
      \***********************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesPerfilPerfilPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n\n.container-skeleton {\n  margin-left: 20%;\n  line-height: 30px;\n  border-radius: 9px;\n  margin-top: 10px;\n}\n\n.avatar {\n  border-radius: 100px;\n  height: 120px;\n  width: 120px;\n  position: relative;\n  margin: auto;\n  top: -80px;\n  box-shadow: 0 0 0 13px #f0f0f0;\n  margin-bottom: -65px;\n}\n\nh2 {\n  font-size: 32px;\n  font-weight: 600;\n  margin-bottom: 15px;\n  color: #333;\n}\n\nh4 {\n  font-size: 13px;\n  color: #00baff;\n  letter-spacing: 1px;\n  margin-bottom: 25px;\n}\n\np {\n  font-size: 16px;\n  line-height: 26px;\n  margin-bottom: 20px;\n  color: #666;\n}\n\nion-icon {\n  color: #508bfa;\n}\n\nion-input {\n  --color: black;\n}\n\nion-list {\n  background-color: #FFF;\n  padding-top: 7%;\n}\n\nion-item {\n  --border-color: transparent !important;\n  --background: #F7F7F6;\n  border-radius: 14px;\n  margin-bottom: 10px;\n  margin-top: 10px;\n}\n\n.item-skeleton {\n  border-radius: 14px;\n  margin-left: 4%;\n  line-height: 45px;\n  margin-bottom: 7%;\n}\n\n.button-skeleton {\n  border-radius: 18px;\n  line-height: 47px;\n  margin-top: 10%;\n  margin-left: 15px;\n}\n\n.margin {\n  margin-left: 4%;\n  margin-bottom: 5%;\n}\n\n.button-save {\n  --background: #2D383F;\n  color: white;\n  margin-top: 10%;\n}\n\nion-toolbar {\n  --background: #2D383F;\n  color: white;\n}\n\n.skeleton-img {\n  line-height: 167px;\n  --border-radius: 3px;\n  margin-top: -7px;\n}\n\n.button-clean {\n  --background: white;\n  margin-top: 10%;\n}\n\n.margin-bottom {\n  margin-bottom: 25px;\n}\n\n.margin-top-menos {\n  margin-top: -20px;\n}\n\nion-content {\n  --background: #F4F3EF;\n}\n\n.img {\n  margin-top: -30px;\n  margin-left: -17px;\n  margin-right: -17px;\n}\n\n.fotoPerfil {\n  width: 100%;\n  height: 60%;\n  --background: #2D383F;\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcGVyZmlsL3BlcmZpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLGFBQUE7RUFDRSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFDTjs7QUFFRTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBRUU7RUFDRSxvQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLDhCQUFBO0VBQ0Esb0JBQUE7QUFDSjs7QUFFRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQUNKOztBQUNFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0FBRUo7O0FBQUU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QUFHSjs7QUFBRTtFQUNJLGNBQUE7QUFHTjs7QUFBRTtFQUNJLGNBQUE7QUFHTjs7QUFBRTtFQUNJLHNCQUFBO0VBQ0EsZUFBQTtBQUdOOztBQUFFO0VBQ0Usc0NBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQUdKOztBQUFFO0VBQ0UsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQUdKOztBQUFFO0VBQ0UsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUdKOztBQUFFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBR0o7O0FBQUU7RUFDSSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBR047O0FBQUU7RUFDRSxxQkFBQTtFQUNBLFlBQUE7QUFHSjs7QUFBRTtFQUNFLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxnQkFBQTtBQUdKOztBQUFFO0VBQ0UsbUJBQUE7RUFDQSxlQUFBO0FBR0o7O0FBQUU7RUFDRSxtQkFBQTtBQUdKOztBQUFFO0VBQ0UsaUJBQUE7QUFHSjs7QUFBRTtFQUNFLHFCQUFBO0FBR0o7O0FBQUU7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFHSjs7QUFBRTtFQUNFLFdBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDRSxZQUFBO0FBR04iLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9wZXJmaWwvcGVyZmlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgfVxyXG4gIFxyXG4gIC5jb250YWluZXItc2tlbGV0b257XHJcbiAgICBtYXJnaW4tbGVmdDogMjAlO1xyXG4gICAgbGluZS1oZWlnaHQ6IDMwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA5cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIH1cclxuICBcclxuICAuYXZhdGFye1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwcHg7XHJcbiAgICBoZWlnaHQ6IDEyMHB4O1xyXG4gICAgd2lkdGg6IDEyMHB4O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgdG9wOiAtODBweDtcclxuICAgIGJveC1zaGFkb3c6IDAgMCAwIDEzcHggI2YwZjBmMDtcclxuICAgIG1hcmdpbi1ib3R0b206IC02NXB4O1xyXG4gIH1cclxuICBcclxuICBoMiB7XHJcbiAgICBmb250LXNpemU6IDMycHg7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAgIGNvbG9yOiAjMzMzO1xyXG4gIH1cclxuICBoNCB7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBjb2xvcjogIzAwYmFmZjtcclxuICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyNXB4XHJcbiAgfVxyXG4gIHAge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gICAgY29sb3I6ICM2NjY7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1pY29uIHtcclxuICAgICAgY29sb3I6IHJnYig4MCwgMTM5LCAyNTApO1xyXG4gIH1cclxuICBcclxuICBpb24taW5wdXQge1xyXG4gICAgICAtLWNvbG9yOiBibGFjaztcclxuICB9XHJcbiAgXHJcbiAgaW9uLWxpc3Qge1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkZGO1xyXG4gICAgICBwYWRkaW5nLXRvcDogNyU7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1pdGVtIHtcclxuICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRjdGN0Y2O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTRweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIH1cclxuICBcclxuICAuaXRlbS1za2VsZXRvbntcclxuICAgIGJvcmRlci1yYWRpdXM6IDE0cHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNCU7XHJcbiAgICBsaW5lLWhlaWdodDogNDVweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDclO1xyXG4gIH1cclxuICBcclxuICAuYnV0dG9uLXNrZWxldG9ue1xyXG4gICAgYm9yZGVyLXJhZGl1czogMThweDtcclxuICAgIGxpbmUtaGVpZ2h0OiA0N3B4O1xyXG4gICAgbWFyZ2luLXRvcDogMTAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDE1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5tYXJnaW57XHJcbiAgICBtYXJnaW4tbGVmdDogNCU7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA1JTtcclxuICB9XHJcbiAgXHJcbiAgLmJ1dHRvbi1zYXZle1xyXG4gICAgICAtLWJhY2tncm91bmQ6ICMyRDM4M0Y7XHJcbiAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgbWFyZ2luLXRvcDogMTAlO1xyXG4gIH1cclxuICBcclxuICBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogIzJEMzgzRjtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiAgXHJcbiAgLnNrZWxldG9uLWltZyB7XHJcbiAgICBsaW5lLWhlaWdodDogMTY3cHg7XHJcbiAgICAtLWJvcmRlci1yYWRpdXM6IDNweDtcclxuICAgIG1hcmdpbi10b3A6IC03cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5idXR0b24tY2xlYW57XHJcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgbWFyZ2luLXRvcDogMTAlO1xyXG4gIH1cclxuICBcclxuICAubWFyZ2luLWJvdHRvbXtcclxuICAgIG1hcmdpbi1ib3R0b206IDI1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5tYXJnaW4tdG9wLW1lbm9ze1xyXG4gICAgbWFyZ2luLXRvcDogLTIwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1jb250ZW50e1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRjRGM0VGO1xyXG4gIH1cclxuICBcclxuICAuaW1ne1xyXG4gICAgbWFyZ2luLXRvcDogLTMwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogLTE3cHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IC0xN3B4O1xyXG4gIH1cclxuICBcclxuICAuZm90b1BlcmZpbHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA2MCU7XHJcbiAgICAtLWJhY2tncm91bmQ6ICMyRDM4M0Y7XHJcbiAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICB9Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/perfil/perfil.page.ts":
    /*!*********************************************!*\
      !*** ./src/app/pages/perfil/perfil.page.ts ***!
      \*********************************************/

    /*! exports provided: PerfilPage */

    /***/
    function srcAppPagesPerfilPerfilPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PerfilPage", function () {
        return PerfilPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var _services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../services/user.service */
      "./src/app/services/user.service.ts");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _services_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../services/alert.service */
      "./src/app/services/alert.service.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var PerfilPage = /*#__PURE__*/function () {
        function PerfilPage(userService, storage, alertService, navCtrl, modalController) {
          _classCallCheck(this, PerfilPage);

          this.userService = userService;
          this.storage = storage;
          this.alertService = alertService;
          this.navCtrl = navCtrl;
          this.modalController = modalController;
          this.mostrarData = false;
          this.items = Array(3);
          this.myImage = null;
          this.pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          this.profileForm = this.createFormGroup();
        }

        _createClass(PerfilPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            this.getData();
            this.getFoto();
          }
        }, {
          key: "createFormGroup",
          value: function createFormGroup() {
            return new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
              nombre: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]),
              mail: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].pattern(this.pattern)]),
              telefono: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])
            });
          }
        }, {
          key: "defaultValue",
          value: function defaultValue(perfilData) {
            this.profileForm.controls.nombre.setValue(perfilData.nombre);
            this.profileForm.controls.mail.setValue(perfilData.mail);
            this.profileForm.controls.telefono.setValue(perfilData.telefono);
          }
        }, {
          key: "getData",
          value: function getData() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var datosUsuario;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.storage.get('datos');

                    case 2:
                      datosUsuario = _context.sent;

                      if (!datosUsuario) {
                        _context.next = 7;
                        break;
                      }

                      _context.next = 6;
                      return this.userService.getPerfil(datosUsuario.codigo);

                    case 6:
                      _context.sent.subscribe(function (resp) {
                        _this.perfilData = resp.data;

                        _this.defaultValue(_this.perfilData);

                        _this.mostrarData = true;
                      });

                    case 7:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "getFoto",
          value: function getFoto() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this2 = this;

              var datosUsuario;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.storage.get('datos');

                    case 2:
                      datosUsuario = _context2.sent;

                      if (!datosUsuario) {
                        _context2.next = 7;
                        break;
                      }

                      _context2.next = 6;
                      return this.userService.getFoto(datosUsuario.codigo);

                    case 6:
                      _context2.sent.subscribe(function (resp) {
                        _this2.urlFoto = resp.data.url_foto;
                        _this2.mostrarData = true;
                      });

                    case 7:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "clean",
          value: function clean() {
            this.profileForm.reset();
          }
        }, {
          key: "editProfile",
          value: function editProfile() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var _this3 = this;

              var datosUsuario;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.storage.get('datos');

                    case 2:
                      datosUsuario = _context3.sent;

                      if (!datosUsuario) {
                        _context3.next = 8;
                        break;
                      }

                      _context3.next = 6;
                      return this.userService.editProfile(datosUsuario.codigo, this.profileForm.value.nombre, this.profileForm.value.mail, this.profileForm.value.telefono);

                    case 6:
                      _context3.next = 8;
                      return _context3.sent.subscribe(function (resp) {
                        if (resp.status) {
                          _this3.mostrarData = false;

                          _this3.alertService.presentToast('Registro actualizado!', 'dark', 2500);

                          _this3.getData();
                        } else {
                          _this3.alertService.presentToast('Ha ocurrido un error, intenta más tarde', 'success', 2500);
                        }
                      });

                    case 8:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "back",
          value: function back() {
            this.navCtrl.back({
              animated: true
            });
          }
        }, {
          key: "nombre",
          get: function get() {
            return this.profileForm.get('nombre');
          }
        }, {
          key: "mail",
          get: function get() {
            return this.profileForm.get('mail');
          }
        }, {
          key: "telefono",
          get: function get() {
            return this.profileForm.get('telefono');
          }
        }]);

        return PerfilPage;
      }();

      PerfilPage.ctorParameters = function () {
        return [{
          type: _services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"]
        }, {
          type: _services_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"]
        }];
      };

      PerfilPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-perfil',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./perfil.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/perfil/perfil.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./perfil.page.scss */
        "./src/app/pages/perfil/perfil.page.scss"))["default"]]
      })], PerfilPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-perfil-perfil-module-es5.js.map